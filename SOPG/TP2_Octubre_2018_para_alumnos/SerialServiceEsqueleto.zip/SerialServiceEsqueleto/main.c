#include <stdio.h>
#include <stdlib.h>
#include "SerialManager.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>

#define SERIAL_ADDRESS 		1
#define SERIAL_BAUD_RATE 	115200

struct sockaddr_in serveraddr;
struct sockaddr_in clientaddr;
char buffer_serial[10];
char buffer_tcp[128];
int newfd;
int s;
pthread_mutex_t mutexData = PTHREAD_MUTEX_INITIALIZER;

void init_serial();
void init_socket_tcp();
void* start_serial_thread (void*);
void* start_tcp_thread(void *);

int main(void) {

	init_serial();
	init_socket_tcp();
	

	char buf[10]; 
	pthread_t serial;
	
	pthread_create(&serial, NULL, start_serial_thread, NULL);

	while(1) {
		sleep(1);
	}
}

void init_serial() {
	printf("Inicio Serial Service\r\n");

	serial_open(SERIAL_ADDRESS, SERIAL_BAUD_RATE);
}

void init_socket_tcp() {

	s = socket(PF_INET,SOCK_STREAM, 0);

	struct addrinfo hints;
	struct addrinfo *result;
	
	memset(&hints, 0, sizeof(struct addrinfo));
    	hints.ai_family = AF_INET; // ipv4
    	hints.ai_socktype = SOCK_STREAM; // tcp
    	hints.ai_flags = AI_PASSIVE;    /* For wildcard IP address */

	int r = getaddrinfo(NULL,"10000", &hints, &result); // NULL para localhost
    	if (r != 0) {
        	fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(r));
        	exit(EXIT_FAILURE);
    	}
	if (bind(s, (struct sockaddr*)result->ai_addr, result->ai_addrlen) == -1) {
		close(s);
		perror("listener: bind");
	}

	freeaddrinfo(result);

	if (listen (s, 10) == -1) // backlog=10
  	{
    		perror("error en listen");
    		exit(1);
  	}

}

void* start_serial_thread (void* message) {
	while(1) {
		pthread_mutex_lock(&mutexData);
		int i = serial_receive(buffer_serial, sizeof(buffer_serial));
		pthread_mutex_unlock (&mutexData);
		if (i > 0) {
			printf("%s\n", buffer_serial);

			pthread_t server_tcp;
			
	
			if (pthread_create (&server_tcp, NULL, start_tcp_thread,NULL) < 0) {
				perror("could not create thread");
        		exit(1);
			}
		}
	}
}



void* start_tcp_thread(void * message) {

	socklen_t addr_len = sizeof(struct sockaddr_in);

	if ( (newfd = accept(s, (struct sockaddr *)&clientaddr, &addr_len)) == -1) {
		      perror("error en accept");
		      exit(1);
    }
 	printf  ("server:  conexion desde:  %s\n", inet_ntoa(clientaddr.sin_addr));

	if (write (newfd, buffer_serial, sizeof(buffer_serial)) == -1) {
		perror("Error escribiendo mensaje en socket");
		exit (1);
	}

	int n;
	if( (n = read(newfd,buffer_tcp,128)) == -1 ) {
		perror("Error leyendo mensaje en socket");
		exit(1);
	}

	buffer_tcp[n]=0x00;
	printf("Recibi %d bytes.:%s\n",n,buffer_tcp);

	serial_send(buffer_tcp, sizeof(buffer_tcp));
	

	close(newfd);
	// Cerramos conexion con cliente
	printf("Recibi saliendo del hilo");
	return 0;
}