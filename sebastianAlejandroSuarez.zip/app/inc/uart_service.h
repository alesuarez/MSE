/*
 * uart_service.h
 *
 *  Created on: 18 oct. 2018
 *      Author: alejandro
 */

#ifndef APP_INC_UART_SERVICE_H_
#define APP_INC_UART_SERVICE_H_

#include "sapi.h"

void printOpeningStatus(uint16_t time);
void printClosingStatus(uint16_t time);

#endif /* APP_INC_UART_SERVICE_H_ */
